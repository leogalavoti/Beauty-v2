# Agenda Beauty Nails — Landing Final Auditada

Landing page estática, mobile-first, pronta para substituir os arquivos da landing existente na Vercel.

## Estrutura
- `index.html` — página, SEO, Open Graph, Meta Pixel e CTAs.
- `assets/css/style.css` — estilos responsivos e animações.
- `assets/js/main.js` — InitiateCheckout, preservação de UTMs e reveal no scroll.
- `assets/images/*.webp` — imagens otimizadas usadas pela landing.
- `assets/images/originals/` — PNGs originais preservados, não carregados pela página.
- `favicon.svg` — favicon.

## Publicação
Nenhum build, backend ou variável de ambiente é necessário. Copie o conteúdo para a raiz do projeto Vercel existente.

## Tracking
Pixel: `1072773405680545`
- `PageView`: no carregamento.
- `InitiateCheckout`: somente ao clicar em CTA.
- `Purchase`: não é disparado pela landing; permanece responsabilidade da Kiwify.
- UTMs, `fbclid`, `src` e `sck` são preservados ao avançar para a Kiwify.

## Checkout
Todos os CTAs apontam para: `https://pay.kiwify.com.br/ebQ9LUB`
